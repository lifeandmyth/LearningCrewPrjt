from ._hangle import normalize
from ._hangle import initialize_pattern
