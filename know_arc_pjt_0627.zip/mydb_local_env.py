host = "localhost"
user = "kkm_admin"
password = "kmkim669487"
db = "soloDB"
port = 3306
charset="utf8"